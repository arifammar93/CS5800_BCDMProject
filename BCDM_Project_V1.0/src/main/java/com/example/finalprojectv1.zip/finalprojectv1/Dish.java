package com.example.finalprojectv1;

import java.time.LocalDate;

public class Dish {
    private String name;
    private int ID;
    private double price;

    private LocalDate date;


    public Dish(String name, int id, double price, LocalDate date) {
        this.name = name;
        ID = id;
        this.price = price;
        this.date = date;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setID(int id) {
        ID = id;
    }

    public int getID() {
        return ID;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public double getPrice() {
        return price;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public LocalDate getDate() {
        return date;
    }
}
