package com.example.finalprojectv1;

import java.time.LocalDate;
import java.util.List;

public class Order {
    private List<Dish> cart;
    private double total;
    private int userID;

    private LocalDate date;

    public Order(List<Dish> cart, double total, int userID, LocalDate date){
        this.cart = cart;
        this.total = total;
        this.userID = userID;
        this.date = date;
    }

    public void setCart(List<Dish> cart) {
        this.cart = cart;
    }

    public List<Dish> getCart() {
        return cart;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public double getTotal() {
        return total;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }
    public void addToCart(Dish dish){
        cart.add(dish);
        total += dish.getPrice();
    }
    public void deleteFromCart(String Name){
        for(int i = 0; i < cart.size(); i++){
            if(cart.get(i).getName().equals(Name)) {
                total -= cart.get(i).getPrice();
                cart.remove(i);
                break;
            }
        }
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }
}
